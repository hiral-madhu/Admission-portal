# -*- coding: utf-8 -*-

from flask import Flask, request

app = Flask(__name__)

from flask import render_template
import sqlite3


@app.route('/',methods = ['POST', 'GET'])
def hello_world():
   return render_template('wel.html')

@app.route('/detail',methods = ['POST', 'GET'])
def detail():
   return render_template('detail.html')

@app.route('/editform',methods = ['POST', 'GET'])
def editform():
   with sqlite3.connect("Student.db") as con:
      cur = con.cursor()
      id = 1
      cur.execute("SELECT * FROM student_info WHERE id=?", (id,))
      rows = cur.fetchall()
   if request.method == 'POST':
         id = request.form['stu_id']
         First_name = request.form['First_name']
         Last_name = request.form['Last_name']
         Email = request.form['Email']
         Dob = request.form['Dob']
         Gender = request.form['Gender']
         Area_code = request.form['Area_code']
         Phone_number = request.form['Phone_number']
         Study_field = request.form['Study_field']
         Previous_Course = request.form['Previous_Course']
         Complition_Time = request.form['Complition_Time']
         Student_ID = request.form['Student_ID']
         Password = request.form['Password']
         P_First_name = request.form['P_First_name']
         P_Last_name = request.form['P_Last_name']
         P_Email = request.form['P_Email']
         P_Area_code = request.form['P_Area_code']
         P_Phone_number = request.form['P_Phone_number']
         P_Street_address = request.form['P_Street_address']
         P_Street_address_line_2 = request.form['P_Street_address_line_2']
         P_City = request.form['P_City']
         P_State = request.form['P_State']
         P_Zip_Code = request.form['P_Zip_Code']
         E_Name = request.form['E_Name']
         E_NameRelationship = request.form['E_NameRelationship']
         E_Area_code = request.form['E_Area_code']
         E_Phone = request.form['E_Phone']
         B_name = request.form['B_name']
         B_last_name = request.form['B_last_name']
         B_email = request.form['B_email']
         B_Area_code = request.form['B_Area_code']
         B_Phone_number = request.form['B_Phone_number']
         B_Street_address = request.form['B_Street_address']
         B_Street_address_line_2 = request.form['B_Street_address_line_2']
         B_City = request.form['B_City']
         B_State = request.form['B_State']
         B_Zip_Code = request.form['B_Zip_Code']
         B_Date = request.form['B_Date']
         sqliteConnection = sqlite3.connect('Student.db')
         cursor = sqliteConnection.cursor()
         aaa ="""UPDATE student_info SET First_name=?,Last_name=?,Email=?,Dob=?,Gender=?,Area_code=?,Phone_number=?,Study_field=?,Previous_Course=?,Complition_Time=?,Student_ID=?,Password=?,P_First_name=?,P_Last_name=?,P_Email=?,P_Area_code=?,P_Phone_number=?,P_Street_address=?,P_Street_address_line_2=?,P_City=?,P_State=?,P_Zip_Code=?,E_Name=?,E_NameRelationship=?,E_Area_code=?,E_Phone=?,B_name=?,B_last_name=?,B_email=?,B_Area_code=?,B_Phone_number=?,B_Street_address=?,B_Street_address_line_2=?,B_City=?,B_State=?,B_Zip_Code=?,B_Date=? WHERE id=?"""
         cursor.execute(aaa,(First_name, Last_name, Email, Dob, Gender, Area_code, Phone_number, Study_field, Previous_Course,Complition_Time, Student_ID, Password, P_First_name, P_Last_name, P_Email, P_Area_code, P_Phone_number,P_Street_address, P_Street_address_line_2, P_City, P_State, P_Zip_Code, E_Name, E_NameRelationship,E_Area_code, E_Phone, B_name, B_last_name, B_email, B_Area_code, B_Phone_number,B_Street_address,B_Street_address_line_2,B_City,B_State,B_Zip_Code, B_Date,id))
         sqliteConnection.commit()
         msg = "Record successfully added"
         print(msg)
         with sqlite3.connect("Student.db") as con:
            cur = con.cursor()
            id = 1
            cur.execute("SELECT * FROM student_info WHERE id=?", (id,))
            rows = cur.fetchall()
   return render_template('editform.html',rows=rows)


@app.route('/student_info',methods = ['POST', 'GET'])
def student_info():
   with sqlite3.connect("Student.db") as con:
      id = 1
      cur = con.cursor()
      cur.execute("SELECT * FROM student_info WHERE id=?", (id,))
      rows = cur.fetchall()
      print(rows)
   return render_template('student-info.html',rows=rows)


@app.route('/stu-login',methods = ['POST', 'GET'])
def stu_login():
   if request.method == 'POST':
      email = request.form['email']
      Password = request.form['Password']
      print("8888888888888888888888",email,Password)
      sqliteConnection = sqlite3.connect('Student.db')
      cursor = sqliteConnection.cursor()
      cursor.execute('SELECT * from student_info WHERE Email="%s" AND Password="%s"' % (email, Password))

      if cursor.fetchone() is not None:
         row =cursor.fetchone()
         print(row)
         return render_template('welcome.html')
      else:
         print ("Login failed")
   return render_template('stu-login.html')


@app.route('/form',methods = ['POST', 'GET'])
def form1():
   if request.method == 'POST':
      try:
         First_name = request.form['First_name']
         Last_name = request.form['Last_name']
         Email = request.form['Email']
         Dob = request.form['Dob']
         Gender = request.form['Gender']
         Area_code = request.form['Area_code']
         Phone_number = request.form['Phone_number']
         Study_field = request.form['Study_field']
         Previous_Course = request.form['Previous_Course']
         Complition_Time = request.form['Complition_Time']
         Student_ID = request.form['Student_ID']
         Password = request.form['Password']
         P_First_name = request.form['P_First_name']
         P_Last_name = request.form['P_Last_name']
         P_Email = request.form['P_Email']
         P_Area_code = request.form['P_Area_code']
         P_Phone_number = request.form['P_Phone_number']
         P_Street_address = request.form['P_Street_address']
         P_Street_address_line_2 = request.form['P_Street_address_line_2']
         P_City = request.form['P_City']
         P_State = request.form['P_State']
         P_Zip_Code = request.form['P_Zip_Code']
         E_Name = request.form['E_Name']
         E_NameRelationship = request.form['E_NameRelationship']
         E_Area_code = request.form['E_Area_code']
         E_Phone = request.form['E_Phone']
         B_name = request.form['B_name']
         B_last_name = request.form['B_last_name']
         B_email = request.form['B_email']
         B_Area_code = request.form['B_Area_code']
         B_Phone_number = request.form['B_Phone_number']
         B_Street_address = request.form['B_Street_address']
         B_Street_address_line_2 = request.form['B_Street_address_line_2']
         B_City = request.form['B_City']
         B_State = request.form['B_State']
         B_Zip_Code = request.form['B_Zip_Code']
         B_Date = request.form['B_Date']

         with sqlite3.connect("Student.db") as con:
            cur = con.cursor()
            cur.execute("INSERT INTO student_info (First_name,Last_name,Email,Dob,Gender,Area_code,Phone_number,Study_field,Previous_Course,Complition_Time,Student_ID,Password,P_First_name,P_Last_name,P_Email,P_Area_code,P_Phone_number,P_Street_address,P_Street_address_line_2,P_City,P_State,P_Zip_Code,E_Name,E_NameRelationship,E_Area_code,E_Phone,B_name,B_last_name,B_email,B_Area_code,B_Phone_number,B_Street_address,B_Street_address_line_2,B_City,B_State,B_Zip_Code,B_Date)"
                        " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (First_name,Last_name,Email,Dob,Gender,Area_code,Phone_number,Study_field,Previous_Course,Complition_Time,Student_ID,Password,P_First_name,P_Last_name,P_Email,P_Area_code,P_Phone_number,P_Street_address,P_Street_address_line_2,P_City,P_State,P_Zip_Code,E_Name,E_NameRelationship,E_Area_code,E_Phone,B_name,B_last_name,B_email,B_Area_code,B_Phone_number,B_Street_address,B_Street_address_line_2,B_City,B_State,B_Zip_Code,B_Date) )
            con.commit()
            msg = "Record successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      finally:
         con.close()
   return render_template('form1.html')


if __name__ == '__main__':
   app.run(host='127.0.0.1', port=8000, debug=True)

