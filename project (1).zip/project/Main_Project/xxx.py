import sqlite3

conn = sqlite3.connect("Student.db")
c = conn.cursor()

try:
    c.execute('''CREATE TABLE student_info (
        id INTEGER PRIMARY KEY ,
        First_name VARCRCHAR(100),
        Last_name VARCRCHAR(100),
        Email VARCRCHAR(100),
        Dob VARCRCHAR(100),
        Gender VARCRCHAR(100),
        Area_code VARCRCHAR(100),
        Phone_number VARCRCHAR(100),
        Study_field VARCRCHAR(100),
        Previous_Course VARCRCHAR(100),
        Complition_Time VARCRCHAR(100),
        Student_ID VARCRCHAR(100),
        Password VARCRCHAR(100),
        P_First_name VARCRCHAR(100),
        P_Last_name VARCRCHAR(100),
        P_Email VARCRCHAR(100),
        P_Area_code VARCRCHAR(100),
        P_Phone_number VARCRCHAR(100),
        P_Street_address VARCRCHAR(100),
        P_Street_address_line_2 VARCRCHAR(100),
        P_City VARCRCHAR(100),
        P_State VARCRCHAR(100),
        P_Zip_Code VARCRCHAR(100),
        E_Name VARCRCHAR(100),
        E_NameRelationship VARCRCHAR(100),
        E_Area_code VARCRCHAR(100),
        E_Phone VARCRCHAR(100),
        B_name VARCRCHAR(100),
        B_last_name VARCRCHAR(100),
        B_email VARCRCHAR(100),
        B_Area_code VARCRCHAR(100),
        B_Phone_number VARCRCHAR(100),
        B_Street_address VARCRCHAR(100),
        B_Street_address_line_2 VARCRCHAR(100),
        B_City VARCRCHAR(100),
        B_State VARCRCHAR(100),
        B_Zip_Code VARCRCHAR(100),
        B_Date VARCRCHAR(100))''')
except sqlite3.OperationalError as e:
    print('sqlite error:', e.args[0])  # table companies already exists

conn.commit()

conn.close()

print('done')